package bg.avi.numrec.web.admin.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;

import bg.avi.common.comm.pub.MultipleResponse;
import bg.avi.common.comm.pub.Request;
import bg.avi.common.comm.pub.SingleResponse;
import bg.avi.common.ws.HttpRequest;
import bg.avi.numrec.web.admin.config.Config;

public class HTTPRequestUtil {
	private final static Logger LOGGER = LoggerFactory.getLogger(HTTPRequestUtil.class);
	
	public static SingleResponse doGetSingle(Map<String, String> params, String URL) {
		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/json");
		headers.put("Accept",       "application/json");

		HttpRequest request = new HttpRequest(headers, Config.HTTP_CONN_TIMEOUT, Config.HTTP_READ_TIMEOUT);

		ResponseEntity<SingleResponse> response = null;
		try {
			response = request.doGet(params, URL, SingleResponse.class);
		} catch (HttpStatusCodeException e) { 
			LOGGER.error("Request URI: " + URL + "; Error on request", e);
			return null;
		} catch (Throwable t) {
			LOGGER.error("Unexpected error in uploading data.", t);
			return null;
		}
		return response.getBody();
	}
	
	public static MultipleResponse doGetMultiple(Map<String, String> params, String URL) {
		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/json");
		headers.put("Accept",       "application/json");

		HttpRequest request = new HttpRequest(headers, Config.HTTP_CONN_TIMEOUT, Config.HTTP_READ_TIMEOUT);

		ResponseEntity<MultipleResponse> response = null;
		try {
			response = request.doGet(params, URL, MultipleResponse.class);
		} catch (HttpStatusCodeException e) { 
			LOGGER.error("Request URI: " + URL + "; Error on request", e);
			return null;
		} catch (Throwable t) {
			LOGGER.error("Unexpected error in uploading data.", t);
			return null;
		}
		return response.getBody();
	}

	public static SingleResponse doPost(Request data, String URL) {
		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/json");
		headers.put("Accept",       "application/json");

		HttpRequest request = new HttpRequest(headers, Config.HTTP_CONN_TIMEOUT, Config.HTTP_READ_TIMEOUT);

		ResponseEntity<SingleResponse> response = null;
		try {
			response = request.doPost(data, URL, SingleResponse.class);
		} catch (HttpStatusCodeException e) { 
			LOGGER.error("Request URI: " + URL + "; Error on request", e);
			return null;
		} catch (Throwable t) {
			LOGGER.error("Unexpected error in uploading data.", t);
			return null;
		}
		return response.getBody();
	}
}
