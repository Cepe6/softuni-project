package bg.avi.numrec.web.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import bg.avi.numrec.web.admin.dto.CountryDTO;
import bg.avi.numrec.web.admin.dto.PlatePatternDTO;

@Service
public class PlatePatternService {

	public List<PlatePatternDTO> getAllPatterns() {
		List<PlatePatternDTO> list = new ArrayList<>();
		list.add(new PlatePatternDTO(1, "YY XXXX YY", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		list.add(new PlatePatternDTO(2, "YY XXXXXX", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		
		return list;
	}

	public List<PlatePatternDTO> getPatternsByExample(PlatePatternDTO searchObject) {
		List<PlatePatternDTO> list = new ArrayList<>();
		list.add(new PlatePatternDTO(1, "YY XXXX YY", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		list.add(new PlatePatternDTO(2, "YY XXXXXX", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		
		return null;
	}

	public void saveOrUpdate(PlatePatternDTO addEditObject) {
		// TODO Auto-generated method stub
		
	}

}
