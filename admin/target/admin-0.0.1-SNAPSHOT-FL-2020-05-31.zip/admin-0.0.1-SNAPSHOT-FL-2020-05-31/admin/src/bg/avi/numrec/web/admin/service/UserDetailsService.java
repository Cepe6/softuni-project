package bg.avi.numrec.web.admin.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import bg.avi.numrec.web.admin.dto.UserDTO;

@Service
public class UserDetailsService {

	// FIXME: connect to gateway, not to service
	/*public List<UserDTO> getAllUsers() {
		MultipleResponse response = HTTPRequestUtil.doGetMultiple(null, "http://localhost:8080/authentication/v1.0/accounts/findAll");
		if (response.getMessage().equals(ResponseMessage.SUCCESSFULL)) {
			List<UserDTO> results = new ArrayList<>();
			for (Object obj : response.getResponseEntity()) {
				results.add((UserDTO) obj);
			}
			return results;
		} else return Collections.emptyList();
	}*/
	
	public List<UserDTO> getAllUsers() {
		List<UserDTO> list = new ArrayList<>();
		list.add(new UserDTO("User 1", "Email@e.mail", new Date(), new Date()));
		list.add(new UserDTO("User 2", "Email@e.mail", new Date(), new Date()));
		list.add(new UserDTO("User 3", "Email@e.mail", new Date(), new Date()));
		list.add(new UserDTO("User 41", "Email@e.mail", new Date(), new Date()));
		list.add(new UserDTO("User 5", "Email@e.mail", new Date(), new Date()));
		
		return list;
	}

	public List<UserDTO> getUsersByExample(UserDTO searchObject) {
		List<UserDTO> list = new ArrayList<>();
		list.add(new UserDTO("User 1", "Email@e.mail", new Date(), new Date()));
		list.add(new UserDTO("User 2", "Email@e.mail", new Date(), new Date()));
		list.add(new UserDTO("User 3", "Email@e.mail", new Date(), new Date()));
		list.add(new UserDTO("User 41", "Email@e.mail", new Date(), new Date()));
		list.add(new UserDTO("User 5", "Email@e.mail", new Date(), new Date()));
		
		return list;
	}

}
