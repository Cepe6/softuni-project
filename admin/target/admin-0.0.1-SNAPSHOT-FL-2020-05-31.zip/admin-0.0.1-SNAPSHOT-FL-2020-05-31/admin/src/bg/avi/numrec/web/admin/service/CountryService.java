package bg.avi.numrec.web.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import bg.avi.numrec.web.admin.dto.CountryDTO;

@Service
public class CountryService {

	public List<CountryDTO> getAllCountries() {
		List<CountryDTO> list = new ArrayList<>();
		list.add(new CountryDTO("BG", "Bulgaria", "Email@e.mail"));
		list.add(new CountryDTO("F", "France", "Email@e.mail"));
		list.add(new CountryDTO("AL", "Albania", "Email@e.mail"));
		list.add(new CountryDTO("SER", "Serbia", "Email@e.mail"));
		list.add(new CountryDTO("RU", "Russia", "Email@e.mail"));
		
		return list;
	}

	public List<CountryDTO> getCountriesByExample(CountryDTO searchObject) {
		List<CountryDTO> list = new ArrayList<>();
		list.add(new CountryDTO("BG", "Bulgaria", "Email@e.mail"));
		list.add(new CountryDTO("F", "France", "Email@e.mail"));
		list.add(new CountryDTO("AL", "Albania", "Email@e.mail"));
		list.add(new CountryDTO("SER", "Serbia", "Email@e.mail"));
		list.add(new CountryDTO("RU", "Russia", "Email@e.mail"));
		
		return list;
	}

	public void saveOrUpdate() {
		// TODO Auto-generated method stub
		
	}

}
