package bg.avi.numrec.web.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import bg.avi.numrec.web.admin.dto.CodeTypeDTO;

@Service
public class CodeTypeService {

	public List<CodeTypeDTO> getAllCodeTypes() {
		List<CodeTypeDTO> list = new ArrayList<>();
		list.add(new CodeTypeDTO("F", "Front", "Da"));
		list.add(new CodeTypeDTO("B", "Back", "Da!"));
		
		return list;
	}

}
