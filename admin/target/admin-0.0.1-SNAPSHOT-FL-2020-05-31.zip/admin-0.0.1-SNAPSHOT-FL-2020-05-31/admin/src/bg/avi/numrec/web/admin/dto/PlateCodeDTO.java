package bg.avi.numrec.web.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PlateCodeDTO {
	private String code;
	private CountryDTO country;
	private CodeTypeDTO type;
}
