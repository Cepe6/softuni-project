package bg.avi.numrec.web.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import bg.avi.numrec.web.admin.dto.CodeTypeDTO;
import bg.avi.numrec.web.admin.dto.CountryDTO;
import bg.avi.numrec.web.admin.dto.PlateCodeDTO;

@Service
public class PlateCodeService {

	public List<PlateCodeDTO> getAllCodes() {
		List<PlateCodeDTO> list = new ArrayList<>();
		list.add(new PlateCodeDTO("��", new CountryDTO("BG", "Bulgaria", "Email@e.mail"), new CodeTypeDTO("F", "Front", "")));
		list.add(new PlateCodeDTO("��", new CountryDTO("BG", "Bulgaria", "Email@e.mail"), new CodeTypeDTO("F", "Front", "")));
		
		return list;
	}

	public List<PlateCodeDTO> getCodesByExample(PlateCodeDTO searchObject) {
		List<PlateCodeDTO> list = new ArrayList<>();
		list.add(new PlateCodeDTO("��", new CountryDTO("BG", "Bulgaria", "Email@e.mail"), new CodeTypeDTO("F", "Front", "")));
		list.add(new PlateCodeDTO("��", new CountryDTO("BG", "Bulgaria", "Email@e.mail"), new CodeTypeDTO("F", "Front", "")));
		
		return list;
	}

	public void saveOrUpdate(PlateCodeDTO addEditObject) {
		// TODO Auto-generated method stub
		
	}

}
