package bg.avi.numrec.web.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import bg.avi.numrec.web.admin.dto.CarPlateDTO;
import bg.avi.numrec.web.admin.dto.CountryDTO;

@Service
public class CarPlateService {

	public List<CarPlateDTO> getAllPlates() {
		/*MultipleResponse response = HTTPRequestUtil.doGetMultiple(null, Config.APPLICATION_BASE_PATH + "/plates/findAll");
		if (response.getMessage().equals(ResponseMessage.SUCCESSFULL)) {
			List<CarPlateDTO> results = new ArrayList<>();
			for (Object obj : response.getResponseEntity()) {
				results.add((CarPlateDTO) obj);
			}
			return results;
		} else return Collections.emptyList();*/
		
		List<CarPlateDTO> list = new ArrayList<>();
		list.add(new CarPlateDTO("�� 4813 ��", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		list.add(new CarPlateDTO("�� 4813 ��", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		list.add(new CarPlateDTO("�� 4813 ��", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		list.add(new CarPlateDTO("�� 4813 ��", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		list.add(new CarPlateDTO("�� 4813 ��", new CountryDTO("BG", "Bulgaria", "Email@e.mail")));
		
		return list;
	}

	public List<CarPlateDTO> getPlatesByExample(CarPlateDTO searchObject) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
